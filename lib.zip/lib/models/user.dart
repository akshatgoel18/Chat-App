class User{
  String uid;
  User({this.uid});


}